#!/usr/bin/env python3
"""
Rigol CAN Waveform Generator and USB Transfer Tool
Generates and transfers CAN-H/CAN-L waveforms to Rigol DG822 Pro signal generator.
"""

import os
import json
import csv
import sys
import time
from pathlib import Path

try:
    import pyvisa
    PYVISA_AVAILABLE = True
except ImportError:
    PYVISA_AVAILABLE = False
    print("Warning: pyvisa not installed. USB transfer disabled.")
    print("Install with: python -m pip install pyvisa")


class RigolWaveformManager:
    """Manages waveform generation and transfer to Rigol signal generator."""
    
    def __init__(self):
        self.waveforms_dir = Path(__file__).parent / "waveforms"
        self.rigol = None
        self.rigol_resource = None
        self.waveform_scenarios = [
            "base",
            "timing_glitch",
            "slow_edges",
            "ringing",
            "dropped_bits",
            "voltage_spikes",
            "noise_overlay"
        ]
        
    def detect_rigol(self):
        """Detect and connect to Rigol device via USB."""
        if not PYVISA_AVAILABLE:
            print("❌ PyVISA not available. Cannot detect Rigol device.")
            return False
            
        try:
            rm = pyvisa.ResourceManager()
            resources = rm.list_resources()
            
            if not resources:
                print("❌ No USB instruments detected.")
                return False
            
            print(f"\n📊 Found {len(resources)} USB instrument(s):")
            for i, resource in enumerate(resources, 1):
                print(f"  {i}. {resource}")
            
            # Try to connect to first Rigol device
            for resource in resources:
                if "RIGOL" in resource.upper() or "DG8" in resource:
                    try:
                        self.rigol = rm.open_resource(resource)
                        self.rigol_resource = resource
                        
                        # Verify it's a Rigol
                        idn = self.rigol.query("*IDN?")
                        print(f"✅ Connected: {idn}")
                        return True
                    except Exception as e:
                        print(f"⚠️ Failed to connect to {resource}: {e}")
                        continue
            
            # If no Rigol found explicitly, try the first device
            if not self.rigol:
                try:
                    self.rigol = rm.open_resource(resources[0])
                    self.rigol_resource = resources[0]
                    idn = self.rigol.query("*IDN?")
                    print(f"✅ Connected to: {idn}")
                    return True
                except Exception as e:
                    print(f"❌ Failed to connect: {e}")
                    return False
                    
        except Exception as e:
            print(f"❌ Error detecting Rigol: {e}")
            return False
    
    def load_waveform_csv(self, scenario_name):
        """Load waveform data from CSV file."""
        csv_path = self.waveforms_dir / f"{scenario_name}.csv"
        
        if not csv_path.exists():
            print(f"❌ Waveform file not found: {csv_path}")
            return None, None
        
        try:
            can_h_data = []
            can_l_data = []
            
            with open(csv_path, 'r') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    can_h_data.append(float(row['CAN_H_V']))
                    can_l_data.append(float(row['CAN_L_V']))
            
            print(f"✅ Loaded {len(can_h_data)} samples from {scenario_name}.csv")
            return can_h_data, can_l_data
            
        except Exception as e:
            print(f"❌ Error loading CSV: {e}")
            return None, None
    
    def voltage_to_rigol_dac(self, voltage, v_min=0.0, v_max=5.0):
        """
        Convert voltage to Rigol DAC value (0-255 or 0-4095 depending on model).
        Rigol DG822 uses 12-bit DAC (0-4095).
        """
        # Clamp voltage to valid range
        voltage = max(v_min, min(v_max, voltage))
        
        # Convert to 0-4095 range (12-bit DAC)
        dac_value = int((voltage - v_min) / (v_max - v_min) * 4095)
        return dac_value
    
    def prepare_rigol_waveform(self, voltage_data, name="ARB"):
        """
        Prepare waveform data for Rigol arbitrary waveform format.
        Returns waveform as integer array compatible with Rigol.
        """
        # Convert voltages to DAC values
        dac_values = [self.voltage_to_rigol_dac(v, v_min=0, v_max=5.0) 
                      for v in voltage_data]
        
        # Rigol DG822 expects 0-4095 for 12-bit waveforms
        return dac_values
    
    def transfer_to_rigol(self, scenario_name, channel=1):
        """Send waveform to specified Rigol channel."""
        if not self.rigol:
            print("❌ Not connected to Rigol. Run detect_rigol() first.")
            return False
        
        can_h_data, can_l_data = self.load_waveform_csv(scenario_name)
        if can_h_data is None:
            return False
        
        try:
            print(f"\n📤 Preparing to transfer {scenario_name} to Rigol...")
            
            # Prepare waveforms
            h_waveform = self.prepare_rigol_waveform(can_h_data, "CAN_H")
            l_waveform = self.prepare_rigol_waveform(can_l_data, "CAN_L")
            
            # Check waveform length (Rigol DG822 Pro supports up to 65536 samples)
            max_samples = 65536
            if len(h_waveform) > max_samples:
                print(f"⚠️ Waveform too long ({len(h_waveform)} > {max_samples}). Truncating...")
                h_waveform = h_waveform[:max_samples]
                l_waveform = l_waveform[:max_samples]
            
            print(f"  - CAN_H waveform: {len(h_waveform)} samples")
            print(f"  - CAN_L waveform: {len(l_waveform)} samples")
            
            # Reset signal generator
            self.rigol.write("*RST")
            time.sleep(0.5)
            
            # Configure CH1 (CAN_H)
            print("  - Configuring CH1 (CAN_H)...")
            self.rigol.write("SOURCE1:FUNC ARB")  # Set to arbitrary waveform
            self.rigol.write("SOURCE1:ARB:SRAT 1000000")  # 1 MHz sample rate
            
            # Load CAN_H waveform to CH1
            waveform_hex_h = ','.join(str(int(v)) for v in h_waveform)
            self.rigol.write(f"SOURCE1:DATA VOLATILE,{waveform_hex_h}")
            
            # Configure CH2 (CAN_L)
            print("  - Configuring CH2 (CAN_L)...")
            self.rigol.write("SOURCE2:FUNC ARB")  # Set to arbitrary waveform
            self.rigol.write("SOURCE2:ARB:SRAT 1000000")  # 1 MHz sample rate
            
            # Load CAN_L waveform to CH2
            waveform_hex_l = ','.join(str(int(v)) for v in l_waveform)
            self.rigol.write(f"SOURCE2:DATA VOLATILE,{waveform_hex_l}")
            
            # Set output voltage levels (CAN signals typically 0-5V or 0-3.3V)
            print("  - Setting output voltage levels...")
            self.rigol.write("SOURCE1:VOLT 2")  # 2V peak (0-5V range)
            self.rigol.write("SOURCE1:VOLT:OFFSET 2.5")  # 2.5V offset
            self.rigol.write("SOURCE2:VOLT 2")
            self.rigol.write("SOURCE2:VOLT:OFFSET 2.5")
            
            # Enable outputs
            self.rigol.write("OUTPUT1:STATE ON")
            self.rigol.write("OUTPUT2:STATE ON")
            
            print(f"✅ Successfully transferred {scenario_name} to Rigol!")
            print(f"   CH1 (CAN_H) and CH2 (CAN_L) are now outputting the waveform")
            return True
            
        except Exception as e:
            print(f"❌ Error transferring waveform: {e}")
            return False
    
    def display_menu(self):
        """Display interactive menu."""
        print("\n" + "="*60)
        print("🌊 RIGOL CAN WAVEFORM GENERATOR & TRANSFER")
        print("="*60)
        print("\n1. Detect Rigol Device")
        print("2. Transfer Waveform to Rigol (Live Output)")
        print("3. Stop Output")
        print("4. List Available Waveforms")
        print("5. Show Waveform Info")
        print("6. Exit")
        print("\n" + "="*60)
    
    def list_waveforms(self):
        """List all available waveform scenarios."""
        print("\n📋 Available Waveform Scenarios:")
        for i, scenario in enumerate(self.waveform_scenarios, 1):
            csv_file = self.waveforms_dir / f"{scenario}.csv"
            if csv_file.exists():
                # Count rows to get sample count
                with open(csv_file, 'r') as f:
                    count = sum(1 for line in f) - 1  # Subtract header
                print(f"  {i}. {scenario:20} ({count} samples)")
            else:
                print(f"  {i}. {scenario:20} ❌ NOT FOUND")
    
    def show_waveform_info(self, scenario_name):
        """Display information about a specific waveform."""
        csv_path = self.waveforms_dir / f"{scenario_name}.csv"
        
        if not csv_path.exists():
            print(f"❌ Waveform {scenario_name} not found")
            return
        
        try:
            with open(csv_path, 'r') as f:
                reader = csv.DictReader(f)
                h_values = []
                l_values = []
                for row in reader:
                    h_values.append(float(row['CAN_H_V']))
                    l_values.append(float(row['CAN_L_V']))
            
            print(f"\n📊 Waveform Info: {scenario_name}")
            print(f"  Samples: {len(h_values)}")
            print(f"  CAN_H - Min: {min(h_values):.2f}V, Max: {max(h_values):.2f}V, Avg: {sum(h_values)/len(h_values):.2f}V")
            print(f"  CAN_L - Min: {min(l_values):.2f}V, Max: {max(l_values):.2f}V, Avg: {sum(l_values)/len(l_values):.2f}V")
            
        except Exception as e:
            print(f"❌ Error reading waveform info: {e}")
    
    def stop_output(self):
        """Stop output on both channels."""
        if not self.rigol:
            print("❌ Not connected to Rigol")
            return False
        
        try:
            self.rigol.write("OUTPUT1:STATE OFF")
            self.rigol.write("OUTPUT2:STATE OFF")
            print("✅ Output stopped on CH1 and CH2")
            return True
        except Exception as e:
            print(f"❌ Error stopping output: {e}")
            return False
    
    def run_interactive(self):
        """Run interactive menu loop."""
        while True:
            self.display_menu()
            choice = input("Select option (1-6): ").strip()
            
            if choice == "1":
                self.detect_rigol()
            
            elif choice == "2":
                if not self.rigol:
                    print("❌ Must detect Rigol first (option 1)")
                    continue
                
                self.list_waveforms()
                scenario = input("\nEnter scenario name: ").strip()
                
                if scenario in self.waveform_scenarios:
                    self.transfer_to_rigol(scenario)
                else:
                    print(f"❌ Unknown scenario: {scenario}")
            
            elif choice == "3":
                self.stop_output()
            
            elif choice == "4":
                self.list_waveforms()
            
            elif choice == "5":
                self.list_waveforms()
                scenario = input("Enter scenario name: ").strip()
                self.show_waveform_info(scenario)
            
            elif choice == "6":
                print("👋 Exiting...")
                if self.rigol:
                    self.rigol.close()
                break
            
            else:
                print("❌ Invalid option")
            
            input("\nPress Enter to continue...")


def main():
    """Main entry point."""
    manager = RigolWaveformManager()
    
    # Check if waveforms directory exists
    if not manager.waveforms_dir.exists():
        print(f"❌ Waveforms directory not found: {manager.waveforms_dir}")
        print("Please generate waveforms first or check the directory path.")
        sys.exit(1)
    
    # Run interactive menu
    manager.run_interactive()


if __name__ == "__main__":
    main()
